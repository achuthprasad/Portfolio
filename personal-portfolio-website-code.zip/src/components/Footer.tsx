export default function Footer() {
  return (
    <footer className="relative border-t border-white/5 bg-ink-900">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="grid md:grid-cols-3 gap-8 mb-10">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-a flex items-center justify-center font-display font-bold text-white shadow-lg shadow-blue-500/30">
                AP
              </div>
              <div>
                <div className="font-display font-bold text-white">Achuth Prasad T</div>
                <div className="text-[10px] uppercase tracking-[0.2em] text-blue-300/70">Portfolio</div>
              </div>
            </div>
            <p className="text-slate-500 text-sm leading-relaxed max-w-xs">
              BCA Student | Data Analyst Intern @ IIT Palakkad | Building modern web experiences.
            </p>
          </div>

          <div>
            <div className="text-sm font-semibold text-white mb-4">Quick Links</div>
            <ul className="space-y-2 text-sm">
              {['About', 'Skills', 'Experience', 'Projects', 'Contact'].map((l) => (
                <li key={l}>
                  <a href={`#${l.toLowerCase()}`} className="text-slate-400 hover:text-blue-300 transition">
                    {l}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <div className="text-sm font-semibold text-white mb-4">Contact Details</div>
            <ul className="space-y-2 text-sm text-slate-400">
              <li className="flex items-center gap-2">
                <span>📞</span> +91 80781 56118
              </li>
              <li className="flex items-center gap-2">
                <span>✉️</span> achuthprasad.t@gmail.com
              </li>
              <li className="flex items-center gap-2">
                <span>📍</span> Kerala, India
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/5 pt-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-slate-500">
            © 2026 Achuth Prasad T. Crafted with{' '}
            <span className="text-blue-400">React</span> & <span className="text-cyan-300">Tailwind CSS</span>. All rights reserved.
          </p>
          <div className="flex items-center gap-3">
            {[
              { label: 'LinkedIn', href: 'https://www.linkedin.com/in/achuth-prasad-t' },
              { label: 'GitHub', href: 'https://github.com/achuth-prasad' },
              { label: 'Email', href: 'mailto:achuthprasad.t@gmail.com' },
            ].map((s) => (
              <a
                key={s.label}
                href={s.href}
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-lg glass-morphism flex items-center justify-center text-slate-300 hover:text-white hover:bg-white/10 transition text-xs font-semibold"
              >
                {s.label[0]}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}