import GradientCard from './ui/GradientCard';
import SectionHeader from './ui/SectionHeader';

const certs = [
  { name: 'eSim', issuer: 'IIT Bombay', icon: '🔌', color: 'from-blue-500 to-cyan-400' },
  { name: 'GIMP', issuer: 'IIT Bombay', icon: '🎨', color: 'from-violet-500 to-fuchsia-500' },
  { name: 'Data Analytics', issuer: 'Srishti Innovative', icon: '📊', color: 'from-emerald-500 to-teal-500' },
  { name: 'Spoken Tutorial', issuer: 'IIT Bombay', icon: '🎙️', color: 'from-amber-500 to-orange-500' },
];

export default function Education() {
  return (
    <section id="education" className="relative py-28 px-6">
      <div className="absolute inset-0 bg-grid opacity-20" />
      <div className="relative max-w-7xl mx-auto">
        <SectionHeader
          label="Credentials"
          title="Education & Certifications"
          description="Academic background and professional certifications that shape my expertise."
        />

        <div className="grid lg:grid-cols-[1.2fr_1fr] gap-8">
          {/* Education */}
          <GradientCard className="glow-border neon-glow">
            <div className="flex items-start gap-4 mb-6">
              <div className="w-16 h-16 rounded-2xl bg-gradient-a flex items-center justify-center text-2xl shadow-lg shadow-blue-500/20">
                🎓
              </div>
              <div>
                <div className="text-xs uppercase tracking-[0.25em] text-blue-300 mb-2">Current Degree</div>
                <h3 className="font-display text-2xl font-bold text-white">Bachelor of Computer Applications</h3>
                <p className="text-slate-400 mt-2">
                  A comprehensive 3-year program covering programming, databases, networking, operating systems
                  and applied computer science. Currently in 3rd year with specialization in Python, SQL, and data analytics.
                </p>
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4 mt-6">
              {[
                { label: 'Status', value: '3rd Year (Ongoing)' },
                { label: 'Focus', value: 'Programming & Data' },
                { label: 'Current Role', value: 'IIT Palakkad Intern' },
                { label: 'Email', value: 'achuthprasad.t@gmail.com' },
              ].map((item) => (
                <div key={item.label} className="glass-morphism rounded-xl p-3">
                  <div className="text-[10px] uppercase tracking-wider text-slate-400">{item.label}</div>
                  <div className="text-white font-medium">{item.value}</div>
                </div>
              ))}
            </div>
          </GradientCard>

          {/* Certifications */}
          <div className="grid grid-cols-2 gap-4">
            {certs.map((c) => (
              <GradientCard key={c.name} className="glow-border card-hover">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${c.color} flex items-center justify-center text-2xl mb-3 shadow-lg`}>
                  {c.icon}
                </div>
                <div className="font-display font-bold text-lg text-white">{c.name}</div>
                <div className="text-xs text-slate-400 mt-1">{c.issuer}</div>
                <div className="mt-3 pt-2 border-t border-white/5 flex items-center gap-1.5 text-[11px] text-emerald-300 font-medium">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" />
                  </svg>
                  Certified
                </div>
              </GradientCard>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}