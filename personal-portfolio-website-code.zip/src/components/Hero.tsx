import { useEffect, useState } from 'react';
import GradientCard from './ui/GradientCard';

const roles = ['Data Analyst', 'Python Developer', 'BCA Student', 'SQL Enthusiast', 'Problem Solver'];

export default function Hero() {
  const [text, setText] = useState('');
  const [roleIdx, setRoleIdx] = useState(0);
  const [deleting, setDeleting] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    if (!mounted) return;
    const current = roles[roleIdx];
    const speed = deleting ? 45 : 95;
    const t = setTimeout(() => {
      if (!deleting) {
        const next = current.slice(0, text.length + 1);
        setText(next);
        if (next === current) setTimeout(() => setDeleting(true), 1400);
      } else {
        const next = current.slice(0, text.length - 1);
        setText(next);
        if (next === '') {
          setDeleting(false);
          setRoleIdx((i) => (i + 1) % roles.length);
        }
      }
    }, speed);
    return () => clearTimeout(t);
  }, [text, deleting, roleIdx, mounted]);

  return (
    <section id="home" className="relative min-h-screen flex items-center pt-24 pb-20 overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 bg-grid opacity-20" />
      <div className="absolute top-20 -left-32 w-[600px] h-[600px] bg-blue-600/20 rounded-full blur-3xl animate-pulse" />
      <div className="absolute bottom-20 -right-32 w-[500px] h-[500px] bg-violet-600/15 rounded-full blur-3xl animate-pulse animation-delay-2000" />

      <div className="relative max-w-7xl mx-auto px-6 w-full">
        <div className="grid lg:grid-cols-[1.2fr_1fr] gap-16 items-center">
          {/* Left */}
          <div className="space-y-8">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 chip chip-active">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75 animate-ping" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-400" />
              </span>
              Available for new opportunities
            </div>

            {/* Heading */}
            <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold leading-tight tracking-tight">
              Hi, I'm{' '}
              <span className="text-gradient">
                Achuth Prasad
                <br />
                T
              </span>
            </h1>

            {/* Animated role */}
            <div className="text-2xl sm:text-3xl font-medium text-slate-300 h-12">
              I'm a{' '}
              <span className="text-gradient font-semibold">
                {text}
                <span className="inline-block w-0.5 h-7 bg-blue-400 ml-1 align-middle animate-pulse" />
              </span>
            </div>

            {/* Description */}
            <p className="text-slate-400 text-lg max-w-2xl leading-relaxed">
              <span className="text-white font-medium">BCA 3rd-year student</span> at the intersection of{' '}
              <span className="text-cyan-300">data analytics</span>, <span className="text-cyan-300">programming</span>,
              and <span className="text-cyan-300">innovative technology</span>. Currently interning at{' '}
              <span className="text-blue-300 font-medium">IIT Palakkad</span>.
            </p>

            {/* Actions */}
            <div className="flex flex-wrap gap-4 pt-4">
              <a
                href="#contact"
                className="group inline-flex items-center gap-2.5 px-7 py-3.5 rounded-2xl bg-gradient-a text-white font-semibold shadow-2xl shadow-blue-500/30 hover:shadow-blue-500/50 hover:-translate-y-0.5 transition-all duration-300"
              >
                Let's Connect
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" className="group-hover:translate-x-1 transition">
                  <path d="M5 12h14M13 6l6 6-6 6" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </a>
              <a
                href="#projects"
                className="inline-flex items-center gap-2.5 px-7 py-3.5 rounded-2xl glass-morphism text-white font-semibold hover:bg-white/10 transition-all duration-300"
              >
                View Work
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M8 5v14l11-7z" strokeLinejoin="round" />
                </svg>
              </a>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 pt-6 max-w-lg">
              {[
                { n: '3rd', l: 'Year BCA' },
                { n: '7+', l: 'Tech Skills' },
                { n: '1', l: 'IIT Internship' },
              ].map((s) => (
                <div key={s.l} className="text-center">
                  <div className="font-display text-3xl sm:text-4xl font-bold text-gradient">{s.n}</div>
                  <div className="text-[11px] uppercase tracking-[0.2em] text-slate-500 mt-1">{s.l}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Right - Profile Card */}
          <div className="justify-self-center lg:justify-self-end">
            <div className="relative">
              {/* Glow layers */}
              <div className="absolute -inset-8 rounded-[3rem] bg-gradient-a opacity-30 blur-3xl animate-pulse" />
              <div className="absolute -inset-4 rounded-[2.5rem] bg-gradient-a opacity-20 blur-2xl" />

              {/* Card */}
              <GradientCard className="relative w-[280px] sm:w-[320px] overflow-hidden">
                {/* Header visual */}
                <div className="h-40 w-full rounded-2xl bg-gradient-a mb-6 relative overflow-hidden">
                  <div className="absolute inset-0 shimmer" />
                  <div className="relative h-full flex items-center justify-center">
                    <span className="text-7xl font-display font-bold text-white drop-shadow-2xl">AP</span>
                  </div>
                </div>

                {/* Info */}
                <div className="space-y-4">
                  <div>
                    <h3 className="font-display text-2xl font-bold text-white">Achuth Prasad T</h3>
                    <p className="text-blue-300 text-sm font-medium">BCA Student | Data Analyst</p>
                  </div>

                  <div className="space-y-3">
                    {[
                      { icon: '📍', label: 'Location', value: 'Kerala, India' },
                      { icon: '🏛️', label: 'Internship', value: 'IIT Palakkad' },
                      { icon: '📧', label: 'Email', value: 'achuthprasad.t@gmail.com' },
                      { icon: '📱', label: 'Phone', value: '+91 80781 56118' },
                    ].map((item) => (
                      <div key={item.label} className="flex items-center gap-3 text-sm">
                        <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-base">
                          {item.icon}
                        </div>
                        <div>
                          <div className="text-[10px] uppercase tracking-wider text-slate-400">{item.label}</div>
                          <div className="text-white font-medium">{item.value}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </GradientCard>

              {/* Floating badges */}
              <div className="absolute -top-4 -left-4 glass-morphism-strong rounded-2xl px-4 py-3 shadow-2xl animate-float">
                <div className="text-2xl mb-1">🐍</div>
                <div className="text-[10px] uppercase tracking-wider text-slate-400">Python</div>
              </div>
              <div className="absolute -bottom-4 -right-4 glass-morphism-strong rounded-2xl px-4 py-3 shadow-2xl animate-float animation-delay-2000">
                <div className="text-2xl mb-1">📊</div>
                <div className="text-[10px] uppercase tracking-wider text-slate-400">Analytics</div>
              </div>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <a
          href="#about"
          className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-slate-400 hover:text-white transition"
        >
          <span className="text-xs uppercase tracking-[0.3em]">Scroll</span>
          <div className="w-6 h-10 rounded-full border-2 border-slate-500 flex items-start justify-center p-1.5">
            <div className="w-1 h-2 rounded-full bg-blue-400 animate-bounce" />
          </div>
        </a>
      </div>
    </section>
  );
}