import GradientCard from './ui/GradientCard';
import SectionHeader from './ui/SectionHeader';

const timeline = [
  {
    side: 'left',
    date: '2025 — Present',
    role: 'Research & Development Intern',
    org: 'IIT Palakkad',
    type: 'Internship',
    color: 'from-emerald-500 to-teal-500',
    points: [
      'Working on real-world research and technical projects under IIT mentorship.',
      'Applying programming and data analysis skills in a professional research environment.',
      'Collaborating with academic teams to deliver structured deliverables.',
    ],
  },
  {
    side: 'right',
    date: '2024',
    role: 'Data Analytics Certification',
    org: 'Srishti Innovative',
    type: 'Add-on Course',
    color: 'from-violet-500 to-fuchsia-500',
    points: [
      'Comprehensive training in data analytics workflows and tools.',
      'Hands-on practice with Excel, SQL and analytical problem-solving.',
      'Built mini-projects involving real datasets and visualizations.',
    ],
  },
  {
    side: 'left',
    date: '2023 — 2024',
    role: 'Add-on Online Courses',
    org: 'IIT Bombay (Spoken Tutorial)',
    type: 'Certifications',
    color: 'from-blue-500 to-cyan-400',
    points: [
      'eSim — Open source EDA tool for circuit design and simulation.',
      'GIMP — Image editing and digital design fundamentals.',
      'Continuous self-paced learning in cutting-edge open-source tools.',
    ],
  },
  {
    side: 'right',
    date: '2023 — Present',
    role: 'Bachelor of Computer Applications (BCA)',
    org: 'Currently in 3rd Year',
    type: 'Education',
    color: 'from-amber-500 to-orange-500',
    points: [
      'Core subjects: Programming, DBMS, Networking, Software Engineering.',
      'Specializing in Python, C, SQL and data-driven applications.',
      'Active participation in academic projects and tech learning.',
    ],
  },
];

export default function Experience() {
  return (
    <section id="experience" className="relative py-28 px-6">
      <div className="relative max-w-7xl mx-auto">
        <SectionHeader
          label="My Journey"
          title="Experience & Education"
          description="A timeline of academic milestones, certifications, and professional growth."
        />

        <div className="relative max-w-4xl mx-auto">
          {/* Center line */}
          <div className="absolute left-6 md:left-1/2 md:-translate-x-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-blue-500/40 to-transparent" />

          <div className="space-y-10">
            {timeline.map((t, i) => (
              <div key={i} className="relative flex flex-col md:flex-row md:items-center">
                {/* Dot */}
                <div className="absolute left-6 md:left-1/2 md:-translate-x-1/2 w-4 h-4 rounded-full bg-ink-950 border-2 border-blue-400 z-10 shadow-[0_0_20px_rgba(96,165,250,0.6)]" />

                {/* Content */}
                <div className={`md:w-1/2 pl-16 md:pl-0 ${t.side === 'right' ? 'md:order-2 md:pl-16' : 'md:pr-16'}`}>
                  <GradientCard className="glow-border" hover>
                    <div className="flex items-start justify-between mb-4">
                      <span className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-gradient-to-r ${t.color} text-white text-xs font-semibold shadow-lg`}>
                        <span>{t.type}</span>
                      </span>
                      <span className="text-xs font-mono text-slate-400">{t.date}</span>
                    </div>
                    <h3 className="font-display font-bold text-xl text-white mb-1">{t.role}</h3>
                    <div className="text-blue-300 text-sm font-medium mb-4">{t.org}</div>
                    <ul className="space-y-2">
                      {t.points.map((p, j) => (
                        <li key={j} className="text-slate-400 text-sm flex gap-2">
                          <span className="text-blue-400 mt-1">▹</span>
                          <span>{p}</span>
                        </li>
                      ))}
                    </ul>
                  </GradientCard>
                </div>

                <div className="hidden md:block md:w-1/2" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}