import GradientCard from './ui/GradientCard';
import SectionHeader from './ui/SectionHeader';

const highlights = [
  { icon: '🎓', title: 'BCA 3rd Year', desc: 'Currently pursuing Bachelor of Computer Applications.' },
  { icon: '🏛️', title: 'IIT Palakkad', desc: 'Active internship gaining real-world experience.' },
  { icon: '📚', title: 'IIT Bombay Courses', desc: 'Add-on certifications in eSim, GIMP & more.' },
  { icon: '📈', title: 'Data Analytics', desc: 'Trained at Srishti Innovative — analytics focused.' },
];

export default function About() {
  return (
    <section id="about" className="relative py-28 px-6">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-violet-600/10 rounded-full blur-3xl" />
      <div className="relative max-w-7xl mx-auto">
        <SectionHeader
          label="About Me"
          title="My Story"
          description="A blend of academic excellence, hands-on experience, and a passion for technology."
        />

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Left */}
          <div className="space-y-6 text-slate-300 text-lg leading-relaxed">
            <p>
              Hi! I'm <span className="text-white font-semibold gradient-text">Achuth Prasad T</span>, a curious and
              driven <span className="text-blue-300">BCA 3rd-year student</span> with a love for
              technology, data, and clean, purposeful design.
            </p>
            <p>
              My journey spans programming in <span className="text-cyan-300">Python</span> and
              <span className="text-cyan-300"> C</span>, querying databases with{' '}
              <span className="text-cyan-300">SQL</span>, building dashboards in{' '}
              <span className="text-cyan-300">Excel</span>, and understanding the fundamentals of{' '}
              <span className="text-cyan-300">networking</span>.
            </p>
            <p>
              I've expanded my skills through <span className="text-violet-300">add-on courses from IIT Bombay</span>{' '}
              on eSim, GIMP and more, along with a focused <span className="text-violet-300">Data Analytics</span>{' '}
              certification from <span className="text-violet-300">Srishti Innovative</span>. Right now, I'm
              gaining hands-on experience as an <span className="text-emerald-300 font-medium">intern at IIT Palakkad</span>.
            </p>
            <p className="text-slate-400">
              I'm actively looking for opportunities in <span className="text-white">Data Analytics, Data Science,
              Programming</span> and related domains where I can keep growing while delivering real impact.
            </p>

            <div className="flex flex-wrap gap-3 pt-4">
              {['Curious', 'Detail-Oriented', 'Team Player', 'Fast Learner', 'Analytical'].map((t) => (
                <span key={t} className="chip chip-active">
                  {t}
                </span>
              ))}
            </div>
          </div>

          {/* Right */}
          <div className="grid grid-cols-2 gap-4">
            {highlights.map((h) => (
              <GradientCard key={h.title} hover>
                <div className="w-12 h-12 rounded-xl bg-gradient-a flex items-center justify-center text-2xl mb-4 shadow-lg shadow-blue-500/20">
                  {h.icon}
                </div>
                <h3 className="font-display font-bold text-white text-lg mb-2">{h.title}</h3>
                <p className="text-slate-400 text-sm leading-relaxed">{h.desc}</p>
              </GradientCard>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}