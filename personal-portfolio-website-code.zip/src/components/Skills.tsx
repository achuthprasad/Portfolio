import GradientCard from './ui/GradientCard';
import SectionHeader from './ui/SectionHeader';

const skills = [
  {
    category: 'Programming',
    items: [
      { name: 'Python', level: 88, icon: '🐍' },
      { name: 'C Programming', level: 80, icon: '⚙️' },
      { name: 'SQL', level: 82, icon: '🗄️' },
    ],
  },
  {
    category: 'Data & Analytics',
    items: [
      { name: 'Microsoft Excel', level: 90, icon: '📊' },
      { name: 'Data Analytics', level: 78, icon: '📈' },
      { name: 'Data Visualization', level: 75, icon: '📉' },
    ],
  },
  {
    category: 'Systems & Tools',
    items: [
      { name: 'Networking', level: 75, icon: '🌐' },
      { name: 'eSim (IIT Bombay)', level: 70, icon: '🔌' },
      { name: 'GIMP (IIT Bombay)', level: 72, icon: '🎨' },
    ],
  },
];

export default function Skills() {
  return (
    <section id="skills" className="relative py-28 px-6">
      <div className="absolute inset-0 bg-grid opacity-20" />
      <div className="relative max-w-7xl mx-auto">
        <SectionHeader
          label="My Expertise"
          title="Skills & Technologies"
          description="A curated collection of technical skills and tools I work with."
        />

        <div className="grid lg:grid-cols-3 gap-6">
          {skills.map((g) => (
            <GradientCard key={g.category} className="glow-border" hover>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-xl bg-gradient-a flex items-center justify-center text-xl shadow-lg shadow-blue-500/20">
                  {g.category[0]}
                </div>
                <h3 className="font-display font-bold text-xl text-white">{g.category}</h3>
              </div>

              <div className="space-y-5">
                {g.items.map((s) => (
                  <div key={s.name}>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">{s.icon}</span>
                        <span className="font-medium text-white">{s.name}</span>
                      </div>
                      <span className="text-xs font-mono text-blue-300 font-semibold">{s.level}%</span>
                    </div>
                    <div className="progress-bar">
                      <div
                        className="progress-fill bg-gradient-a transition-all duration-1000"
                        style={{ width: `${s.level}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </GradientCard>
          ))}
        </div>

        {/* Tech stack tags */}
        <div className="mt-12 flex flex-wrap justify-center gap-3 pt-6">
          {['Python', 'C', 'SQL', 'Excel', 'Networking', 'Data Analytics', 'eSim', 'GIMP', 'MS Office', 'Power BI', 'Pandas', 'NumPy'].map((t) => (
            <span key={t} className="chip">
              {t}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}