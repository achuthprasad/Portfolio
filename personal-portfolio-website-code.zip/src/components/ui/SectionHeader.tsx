interface Props {
  label: string;
  title: string;
  description?: string;
}

export default function SectionHeader({ label, title, description }: Props) {
  return (
    <div className="text-center mb-16">
      <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass-morphism text-xs font-semibold tracking-[0.3em] uppercase text-blue-300 mb-4">
        <span className="w-1.5 h-1.5 rounded-full bg-blue-400" />
        {label}
      </div>
      <h2 className="font-display text-4xl sm:text-5xl font-bold text-white">{title}</h2>
      {description && (
        <p className="mt-4 text-slate-400 max-w-2xl mx-auto">{description}</p>
      )}
    </div>
  );
}