import { ReactNode } from 'react';

interface Props {
  children: ReactNode;
  className?: string;
  hover?: boolean;
  glow?: boolean;
}

export default function GradientCard({ children, className = '', hover = true, glow = false }: Props) {
  return (
    <div
      className={`
        glass-morphism-strong rounded-3xl p-7 sm:p-8
        ${hover ? 'card-hover' : ''}
        ${glow ? 'neon-glow' : ''}
        ${className}
      `}
    >
      {children}
    </div>
  );
}