import { useState } from 'react';
import GradientCard from './ui/GradientCard';
import SectionHeader from './ui/SectionHeader';

const contacts = [
  {
    label: 'Email',
    value: 'achuthprasad.t@gmail.com',
    href: 'mailto:achuthprasad.t@gmail.com',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M3 7l9 6 9-6M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
      </svg>
    ),
    color: 'from-blue-500 to-cyan-400',
  },
  {
    label: 'Phone',
    value: '+91 80781 56118',
    href: 'tel:+918078156118',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72c.13.96.37 1.9.72 2.81a2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.91.35 1.85.59 2.81.72A2 2 0 0122 16.92z" />
      </svg>
    ),
    color: 'from-emerald-500 to-teal-400',
  },
  {
    label: 'LinkedIn',
    value: 'linkedin.com/in/achuth-prasad-t',
    href: 'https://www.linkedin.com/in/achuth-prasad-t',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
        <path d="M19 3a2 2 0 012 2v14a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h14zM8.34 17V10.67H6.17V17h2.17zM7.25 9.71a1.26 1.26 0 100-2.52 1.26 1.26 0 000 2.52zM18 17v-3.47c0-1.86-.4-3.29-2.57-3.29a2.25 2.25 0 00-2.03 1.11h-.03v-.94H11.3V17h2.17v-3.13c0-.82.16-1.62 1.18-1.62 1 0 1.02.94 1.02 1.68V17H18z" />
      </svg>
    ),
    color: 'from-violet-500 to-fuchsia-500',
  },
  {
    label: 'GitHub',
    value: 'github.com/achuth-prasad',
    href: 'https://github.com/achuth-prasad',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 .5C5.65.5.5 5.65.5 12c0 5.08 3.29 9.39 7.86 10.91.58.1.79-.25.79-.55v-2.04c-3.2.7-3.88-1.37-3.88-1.37-.52-1.34-1.28-1.69-1.28-1.69-1.05-.72.08-.7.08-.7 1.16.08 1.77 1.19 1.77 1.19 1.03 1.77 2.7 1.26 3.36.96.1-.75.4-1.26.73-1.55-2.55-.29-5.24-1.28-5.24-5.7 0-1.26.45-2.29 1.19-3.1-.12-.29-.51-1.47.11-3.06 0 0 .97-.31 3.18 1.18a11 11 0 015.79 0c2.2-1.49 3.17-1.18 3.17-1.18.62 1.59.23 2.77.11 3.06.74.81 1.19 1.84 1.19 3.1 0 4.43-2.69 5.41-5.26 5.69.41.36.78 1.06.78 2.13v3.16c0 .31.21.66.8.55A11.5 11.5 0 0023.5 12C23.5 5.65 18.35.5 12 .5z" />
      </svg>
    ),
    color: 'from-slate-400 to-slate-200',
  },
];

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const subject = encodeURIComponent(`Portfolio enquiry from ${form.name}`);
    const body = encodeURIComponent(`${form.message}\n\n— ${form.name}\n${form.email}`);
    window.location.href = `mailto:achuthprasad.t@gmail.com?subject=${subject}&body=${body}`;
    setSent(true);
    setTimeout(() => setSent(false), 4000);
  };

  return (
    <section id="contact" className="relative py-28 px-6">
      <div className="absolute top-20 right-1/4 w-[400px] h-[400px] bg-violet-600/15 rounded-full blur-3xl" />
      <div className="relative max-w-7xl mx-auto">
        <SectionHeader
          label="Connect"
          title="Let's Build Something Amazing"
          description="I'm open to data analytics, data science, and programming opportunities. Let's talk!"
        />

        <div className="grid lg:grid-cols-[1fr_1.2fr] gap-8">
          {/* Contact info */}
          <div className="space-y-4">
            {contacts.map((c) => (
              <a
                key={c.label}
                href={c.href}
                target={c.href.startsWith('http') ? '_blank' : undefined}
                rel="noreferrer"
                className="group flex items-center gap-4 glass-morphism rounded-2xl p-5 glow-border card-hover"
              >
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${c.color} flex items-center justify-center text-white shadow-lg`}>
                  {c.icon}
                </div>
                <div className="flex-1 min-w-0">                  <div className="text-xs uppercase tracking-wider text-slate-400">{c.label}</div>
                  <div className="text-white font-medium truncate">{c.value}</div>
                </div>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-slate-500 group-hover:text-white group-hover:translate-x-1 transition">
                  <path d="M5 12h14M13 6l6 6-6 6" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </a>
            ))}

            <GradientCard className="glow-border neon-glow mt-4">
              <div className="flex items-center gap-3">
                <span className="relative flex h-3 w-3">
                  <span className="absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75 animate-ping" />
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-400" />
                </span>
                <div>
                  <div className="text-white font-semibold">Open to Opportunities</div>
                  <div className="text-xs text-slate-400">Data Analytics • Data Science • Programming</div>
                </div>
              </div>
            </GradientCard>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="glass-morphism rounded-3xl p-7 sm:p-8 glow-border space-y-5">
            <div className="grid sm:grid-cols-2 gap-5">
              <div>
                <label className="text-xs uppercase tracking-wider text-slate-400 font-semibold">Your Name</label>
                <input
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="mt-2 w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-400/20 transition"
                  placeholder="Achuth Prasad T"
                />
              </div>
              <div>
                <label className="text-xs uppercase tracking-wider text-slate-400 font-semibold">Email</label>
                <input
                  required
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  className="mt-2 w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-400/20 transition"
                  placeholder="you@example.com"
                />
              </div>
            </div>
            <div>
              <label className="text-xs uppercase tracking-wider text-slate-400 font-semibold">Message</label>
              <textarea
                required
                rows={6}
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                className="mt-2 w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-400/20 transition resize-none"
                placeholder="Let's discuss your project or opportunity..."
              />
            </div>
            <button
              type="submit"
              className="w-full inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-2xl bg-gradient-a text-white font-semibold shadow-xl shadow-blue-500/30 hover:shadow-blue-500/60 hover:-translate-y-0.5 transition-all duration-300"
            >
              {sent ? (
                <>
                  <span>Message sent!</span>
                </>
              ) : (
                <>
                  Send Message
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                    <path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}