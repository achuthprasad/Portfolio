import GradientCard from './ui/GradientCard';
import SectionHeader from './ui/SectionHeader';

const projects = [
  {
    title: 'Sales Insights Dashboard',
    desc: 'An interactive Excel + SQL based analytics project transforming raw sales data into actionable KPI dashboards.',
    tags: ['Excel', 'SQL', 'Data Analytics'],
    accent: 'from-blue-500 to-cyan-400',
    emoji: '📊',
  },
  {
    title: 'Student Management System',
    desc: 'A Python + SQL based system to manage student records, marks and attendance with a clean CRUD interface.',
    tags: ['Python', 'SQL', 'CRUD'],
    accent: 'from-violet-500 to-fuchsia-500',
    emoji: '🎓',
  },
  {
    title: 'Network Traffic Analyzer',
    desc: 'A learning project exploring basic packet flow and network behaviour using networking fundamentals.',
    tags: ['Networking', 'Python'],
    accent: 'from-emerald-500 to-teal-400',
    emoji: '🌐',
  },
  {
    title: 'Circuit Simulation in eSim',
    desc: 'Designed and simulated electronic circuits as part of the IIT Bombay add-on course on open-source EDA.',
    tags: ['eSim', 'IIT Bombay'],
    accent: 'from-amber-500 to-orange-500',
    emoji: '🔌',
  },
  {
    title: 'Data Cleaning Toolkit',
    desc: 'Python scripts using pandas to automate data cleaning, deduplication and basic exploratory analysis.',
    tags: ['Python', 'Pandas', 'EDA'],
    accent: 'from-pink-500 to-rose-500',
    emoji: '🧹',
  },
  {
    title: 'Personal Portfolio',
    desc: 'A modern, responsive portfolio showcasing my skills, projects and journey — designed and built from scratch.',
    tags: ['HTML', 'CSS', 'Design'],
    accent: 'from-indigo-500 to-blue-500',
    emoji: '✨',
  },
];

export default function Projects() {
  return (
    <section id="projects" className="relative py-28 px-6">
      <div className="absolute inset-0 bg-grid opacity-20" />
      <div className="relative max-w-7xl mx-auto">
        <SectionHeader
          label="My Work"
          title="Featured Projects"
          description="A showcase of academic projects, course assignments, and learning experiments."
        />

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((p) => (
            <GradientCard key={p.title} className="glow-border card-hover" hover>
              <div className={`h-44 rounded-2xl bg-gradient-to-br ${p.accent} mb-6 relative overflow-hidden shadow-lg shadow-blue-500/20`}>
                <div className="absolute inset-0 shimmer" />
                <div className="relative h-full flex items-center justify-center">
                  <span className="text-6xl">{p.emoji}</span>
                </div>
              </div>

              <h3 className="font-display text-xl font-bold text-white mb-2">{p.title}</h3>
              <p className="text-slate-400 text-sm leading-relaxed mb-4">{p.desc}</p>

              <div className="flex flex-wrap gap-2 mb-4">
                {p.tags.map((t) => (
                  <span key={t} className="chip">
                    {t}
                  </span>
                ))}
              </div>

              <div className="flex items-center gap-2 text-sm font-semibold text-blue-300 opacity-80 group">
                View details
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <path d="M5 12h14M13 6l6 6-6 6" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </div>
            </GradientCard>
          ))}
        </div>
      </div>
    </section>
  );
}